---
agent: pmfkit.constitution
---
